var menuid = '#headnav';
var scrollspeed = 1200;
var menu_active_class = 'active'; 